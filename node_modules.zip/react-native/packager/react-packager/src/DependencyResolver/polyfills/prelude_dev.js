/* eslint global-strict:0 */
__DEV__ = true;

/* global __BUNDLE_START_TIME__:true */
__BUNDLE_START_TIME__ = Date.now();
